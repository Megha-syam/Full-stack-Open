# [Part 0 - Fundamentals of Web apps](https://fullstackopen.com/en/part0)

In this part, we will familiarize ourselves with the practicalities of taking the course. After that we will have an overview of the basics of web development, and also talk about the advances in web application development during the last few decades.

a. [General info](https://fullstackopen.com/en/part0/general_info)  
b. [Fundamental of Web apps](https://fullstackopen.com/en/part0/fundamentals_of_web_apps)
